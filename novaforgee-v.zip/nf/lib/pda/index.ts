import { PublicKey } from '@solana/web3.js'
export const PROGRAM_ID = new PublicKey('GiQ6ov39xDr4HrU1gM9kVJ82e9cVJh5xYMZ8qNtsxMP9')
export const MPL_CORE_ID = new PublicKey('CoREENxT6tW1HoK8ypY1SxRMZTcVPm7R94rH4PZNhX7d')
export function findPlanetPda(asset: PublicKey): [PublicKey, number] {
  return PublicKey.findProgramAddressSync([Buffer.from('planet'), asset.toBuffer()], PROGRAM_ID)
}
export function findTreasuryPda(): [PublicKey, number] {
  return PublicKey.findProgramAddressSync([Buffer.from('treasury')], PROGRAM_ID)
}
