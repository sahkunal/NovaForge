'use client'
import { useMemo } from 'react'
import * as THREE from 'three'
export default function EnergyLane({radius,color='#2d8bff',offset=0}:{radius:number;color?:string;offset?:number}){
 const geometry=useMemo(()=>{
   const g=new THREE.BufferGeometry();const pts=[] as THREE.Vector3[]
   for(let i=0;i<=180;i++){const a=i/180*Math.PI*2;pts.push(new THREE.Vector3(Math.cos(a)*radius,Math.sin(a*2+offset)*.08,Math.sin(a)*radius))}
   g.setFromPoints(pts);g.computeLineDistances();return g
 },[radius,offset])
 return <line geometry={geometry}><lineDashedMaterial color={color} transparent opacity={.34} dashSize={.45} gapSize={.7} linewidth={1} /></line>
}
